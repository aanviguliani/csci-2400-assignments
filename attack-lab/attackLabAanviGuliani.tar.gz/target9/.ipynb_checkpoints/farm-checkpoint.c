/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_294()
{
    return 2512622680U;
}

unsigned getval_220()
{
    return 1491520036U;
}

unsigned addval_349(unsigned x)
{
    return x + 1925419096U;
}

unsigned addval_355(unsigned x)
{
    return x + 3284633932U;
}

unsigned getval_251()
{
    return 1086492760U;
}

unsigned getval_319()
{
    return 3284633928U;
}

unsigned getval_281()
{
    return 3347662863U;
}

unsigned addval_465(unsigned x)
{
    return x + 3347663247U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_477()
{
    return 3223376265U;
}

void setval_327(unsigned *p)
{
    *p = 3674787457U;
}

unsigned addval_336(unsigned x)
{
    return x + 3465122264U;
}

void setval_136(unsigned *p)
{
    *p = 3286276424U;
}

unsigned addval_269(unsigned x)
{
    return x + 3767093340U;
}

unsigned addval_103(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_418(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_489()
{
    return 2496563586U;
}

unsigned addval_316(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_274()
{
    return 2447411528U;
}

unsigned getval_151()
{
    return 3281113481U;
}

void setval_278(unsigned *p)
{
    *p = 3524841865U;
}

unsigned addval_457(unsigned x)
{
    return x + 3525366185U;
}

void setval_277(unsigned *p)
{
    *p = 3223372425U;
}

unsigned addval_192(unsigned x)
{
    return x + 3353381192U;
}

void setval_272(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_423()
{
    return 3680554633U;
}

unsigned addval_383(unsigned x)
{
    return x + 3223372441U;
}

unsigned getval_497()
{
    return 3268315493U;
}

unsigned getval_492()
{
    return 3352201520U;
}

void setval_447(unsigned *p)
{
    *p = 3531133321U;
}

unsigned addval_384(unsigned x)
{
    return x + 3374367368U;
}

unsigned addval_283(unsigned x)
{
    return x + 2425668233U;
}

unsigned addval_458(unsigned x)
{
    return x + 3372794505U;
}

void setval_254(unsigned *p)
{
    *p = 2429651356U;
}

unsigned addval_331(unsigned x)
{
    return x + 3676357256U;
}

unsigned addval_287(unsigned x)
{
    return x + 3281047977U;
}

unsigned getval_167()
{
    return 3526935181U;
}

unsigned getval_250()
{
    return 3685008009U;
}

unsigned getval_140()
{
    return 2881737099U;
}

void setval_236(unsigned *p)
{
    *p = 3380923913U;
}

unsigned getval_356()
{
    return 2464188744U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
